import java.util.HashMap;

public class Room {
    private String name;
    private String description;

    public String getName() {
        return name;
    }

    public void setName(String n) {
        if(!n.equals("")) {
            name = n;
        }
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String d) {
        if(!d.equals("")) {
            description = d;
        }
    }

    public HashMap<String, Room> links = new HashMap<>();

    public void setLink(Room room2, String direction) {
        // we need a "data structure" that can hold
        // a "key" (direction) and a "value" (room2)
        // (in Python this would a dictionary)
        // (in Java, this is called a Map)
        links.put(direction, room2);
    }

    public boolean hasLink(String direction) {
        // look in hashmap to see if direction is a key
        return links.containsKey(direction);
    }

    public Room getLinkedRoom(String direction) {
        return links.get(direction);
    }

    private HashMap<String, Item> roomInventory = new HashMap<>();
    public void addRoomItem(String itemKey, Item itemObject) {
        roomInventory.put(itemKey, itemObject);
    }
    public void removeRoomItem(String itemKey, Item itemObject) {
        roomInventory.remove(itemKey, itemObject);
    }
    public Item getRoomHexKey(String key){return roomInventory.get(key);}

    public java.util.Set<String> getRoomInventory(){
        return roomInventory.keySet();

    }




}
