import java.util.ArrayList;
import java.util.HashMap;

public class Player {

    private Room location;

    private HashMap inventory;


    public Room getLocation() {
        return location;
    }

    public void setLocation(Room loc) {
        location = loc;
    }

    private HashMap<String, Item> playerInventory = new HashMap<>();
    public void addPlayerItem(String itemString, Item itemObject) {
        playerInventory.put(itemString, itemObject);
    }
    public void removePlayerItem(String itemString, Item itemObject) {
        playerInventory.remove(itemString, itemObject);
    }
    public java.util.Set<String> getPlayerInventory(){
        return playerInventory.keySet();
    }
    //public Item getItemObject(String key){}
    public Item getPlayerItemObject(String key){
        return playerInventory.get(key);
    }
    public Item getPlayerHexKey(String key){return playerInventory.get(key);}


}
