import java.security.Principal;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // we call the "Room" the CLASS or template
        // and we call kitchen and livingroom the
        // instances of the class (or "OBJECTS")

        Room kitchen = new Room();
        kitchen.setName("Kitchen");
        kitchen.setDescription("A dank and dirty room buzzing with flies. There is a door to the northeast.");

        Room livingroom = new Room();
        livingroom.setName("Living Room");
        livingroom.setDescription("A Dirty living room that has a door to the southwest.");

        GameMap map = new GameMap();
        map.linkRooms(kitchen, livingroom, "northeast");
        map.linkRooms(livingroom, kitchen, "southwest");

        Player p1 = new Player();
        p1.setLocation(kitchen);

        /// ADDITION OF ITEMS

        Item boxItem = new Item();
        boxItem.setItemName("Box");
        boxItem.setItemDescription("A Cardboard Box");

        Item cupcakeItem = new Item();
        cupcakeItem.setItemName("Cupcake");
        cupcakeItem.setItemDescription("A cupcake from last halloween, Probably toxic");

        Item swordItem = new Item();
        swordItem.setItemName("Sword");
        swordItem.setItemDescription("A Rusty Beat up Sword");

        /// ASSIGNMENT OF ITEMS TO ROOMS

        kitchen.addRoomItem("box", boxItem);
        kitchen.addRoomItem("cupcake", cupcakeItem);
        livingroom.addRoomItem("sword", swordItem);

        Scanner in = new Scanner(System.in);

        System.out.println("Welcome to the Dungeon!");

        // "game loop"
        while(true) {
            // print location info
            System.out.println("you are in the " + p1.getLocation().getName());
            String command = in.next(); // single word
            if(command.equals("look")) {
                System.out.println(p1.getLocation().getDescription());
                System.out.println("The Room Contains: " + p1.getLocation().getRoomInventory());
                System.out.println("You Are Holding: " + p1.getPlayerInventory());
                //if((p1.getLocation()).
            } else if(command.equals("go")) {
                String direction = in.next();
                // check if direction is valid for this room
                if(p1.getLocation().hasLink(direction)) {
                    p1.setLocation(p1.getLocation().getLinkedRoom(direction));
                } else {
                    System.out.println("Bad direction.");
                }
                //////////////////////
                ///Item Interaction///
                //////////////////////
            } else if(command.equals("pickup")) {
                String pickup = in.next();
                if (p1.getLocation().getRoomInventory().contains(pickup)) {
                    p1.addPlayerItem(pickup, p1.getLocation().getRoomHexKey(pickup));
                    p1.getLocation().removeRoomItem(pickup, p1.getLocation().getRoomHexKey(pickup));
                    System.out.println("You have successfully picked up the " + pickup);
                } else {System.out.println("You See no item of the sort.");}
            } else if(command.equals("drop")){
                String drop = in.next();
                if (p1.getPlayerInventory().contains(drop)) {
                    p1.removePlayerItem(drop,p1.getPlayerHexKey(drop));
                    p1.getLocation().addRoomItem(drop,p1.getLocation().getRoomHexKey(drop));
                    System.out.println("You have successfully dropped the " + drop);
                }else {System.out.println("You have no item like that!");}
            } else if(command.equals("examine")){
                String itemExamine = in.next();
                if (p1.getPlayerInventory().contains(itemExamine)){
                    System.out.println((p1.getPlayerItemObject(itemExamine)).getDescription());
                } else {
                    System.out.println("You don't not have that item!");
                }
            }
            //////////////////////
            ///Game Interaction///
            //////////////////////

            else if(command.equals("quit")) {
                break;

            } else { System.out.println("You Have entered an invalid command! Try again.");}

        }

    }
}
