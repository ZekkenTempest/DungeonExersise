import java.util.HashMap;

public class Item {
    private String name;
    private String description;
    public void setItemDescription(String n) {
        if (!n.equals("")) {
            description = n;
        }
    }
    public String getDescription() {
        return description;
    }
    public void setItemName(String n) {
        if (!n.equals("")) {
            name = n;
        }
    }
    public String getName() {
        return name;
    }













}
